package com.example.st10077892imad5112poepart2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import kotlin.math.sqrt

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val number1 = findViewById<EditText>(R.id.etNumber1)
        val number2 = findViewById<EditText>(R.id.etNumber2)
        val addition = findViewById<Button>(R.id.btnAddition)
        val subtraction = findViewById<Button>(R.id.btnSubtraction)
        val multiplication = findViewById<Button>(R.id.btnMultiplication)
        val division = findViewById<Button>(R.id.btnDivision)
        val squareroot = findViewById<Button>(R.id.btnnSquareRoot)
        val power = findViewById<Button>(R.id.btnPower)
        val answer = findViewById<TextView>(R.id.tvAnswer)
        val output = findViewById<TextView>(R.id.tvOutput)
        val error = findViewById<TextView>(R.id.tvNoError)
        val statisticsfunctions = findViewById<Button>(R.id.btnStats)

        addition.setOnClickListener {
            val number1 = number1.text.toString().toInt()
            val number2 = number2.text.toString().toInt()
            val addition = number1 + number2
            output.text = "$number1 + $number2 = $addition"
        }

        subtraction.setOnClickListener {
            val number1 = number1.text.toString().toInt()
            val number2 = number2.text.toString().toInt()
            val subtraction = number1 - number2
            output.text = "$number1 - $number2 = $subtraction"
        }

        multiplication.setOnClickListener {
            val number1 = number1.text.toString().toInt()
            val number2 = number2.text.toString().toInt()
            val multiplication = number1 * number2
            output.text = "$number1 * $number2 = $multiplication"
        }

        division.setOnClickListener {
            if (number1.text.toString() == "") {
                Toast.makeText(this, "Please enter your first number!", Toast.LENGTH_LONG).show()
            }else if (number2.text.toString() == "") {
                Toast.makeText(this, "Please enter your second number!", Toast.LENGTH_LONG).show()
            }else{
                if (number2.text.toString().toInt() == 0){
                    output.text = "Error\nSecond Number Cannot be 0"
                }else{
                    output.text = "${number1.text} / ${number2.text} = " + (number1.text.toString().toDouble() / number2.text.toString().toInt())
                }
            }
        }

        power.setOnClickListener {
            var count1 = number1.text.toString().toInt()
            var count2 = number2.text.toString().toInt()
            var result = 1
            while (count2 > 0){
                result *= count1
                count2--
            }
            output.text = "${number1.text} ^ ${number2.text} = ${result}"
        }

        squareroot.setOnClickListener {
            if (number1.text.toString() == ""){
                Toast.makeText( this, "Please enter your first number!", Toast.LENGTH_LONG).show()
            }else if (number1.text.toString().toInt() < 0){
                val number1 = number1.text.toString().toInt()
                val product = number1 * -1
                output.text = "Square root of ${number1} = " + (sqrt(product.toDouble())).toString() + "1"
            }else{
                output.text = "Square root of ${number1.text} = " + (sqrt(number1.text.toString().toDouble())).toString()
            }
        }
    }
}

